package com.volk_java.ds_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
